<?php
class WPBakeryShortCode_VC_Message extends WPBakeryShortCode {
    public function outputTitle($title) {
        return '';
    }
}